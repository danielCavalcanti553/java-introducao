package javaaula1;

public class Aluno {
    
    String matricula; // String --> caracter
    String nome;
    String endereco;
    String telefone;
    Integer idade; // Integer --> número inteiro
    Double altura; // Double --> Decimal, por exemplo 1.75

    void cadastrar(){
        System.out.println("Aluno cadastrado com sucesso");
    }
}
