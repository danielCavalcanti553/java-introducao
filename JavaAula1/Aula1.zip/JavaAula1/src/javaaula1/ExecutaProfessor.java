package javaaula1;

public class ExecutaProfessor {
    // Classe executável
    public static void main(String args[]){
        // Crie 2 objetos de professor
        Professor p1 = new Professor();
        p1.nome = "Alberto";
        p1.telefone = "(21)9999-0000";
        p1.idade = 35;
        p1.salario = 5250.52;
        p1.altura = 1.79;
        
        Professor p2 = new Professor();
        p2.nome = "Maria";
    }
}
