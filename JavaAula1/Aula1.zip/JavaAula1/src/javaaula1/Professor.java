package javaaula1;

public class Professor {
    
    String nome;
    String curso;
    String endereco;
    String telefone;
    String matricula;
    Double salario;
    Double altura;
    Integer idade;
    
}
